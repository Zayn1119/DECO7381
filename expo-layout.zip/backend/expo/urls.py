from django.contrib import admin
from django.urls import path
from django.http import HttpResponse
from api.views import get_placements, run_layout, viewer

def home(_):
    return HttpResponse("✅ Django server is running. Try /viewer/ or /admin/")

urlpatterns = [
    path('', home),
    path('admin/', admin.site.urls),

    path('api/run_layout', run_layout),
    path('api/placements', get_placements),

    path('viewer/', viewer),
]
