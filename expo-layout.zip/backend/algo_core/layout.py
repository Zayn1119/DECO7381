from typing import List, Dict, Optional, Tuple
import math
import numpy as np

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.cluster import KMeans
    HAS_SK = True
except Exception:
    HAS_SK = False

def _vendor_text(v: Dict) -> str:
    tags = v.get("tags", [])
    words = list(map(str, tags))
    if v.get("vip"): words.append("vip")
    if (v.get("power_kw") or 0) > 1.0: words.append("highpower")
    return " ".join(words) if words else "misc"

def _cluster_labels(vendors: List[Dict]) -> List[int]:
    n = len(vendors)
    if n == 0:
        return []
    if not HAS_SK or n < 3:
        return [0]*n
    corpus = [_vendor_text(v) for v in vendors]
    vec = TfidfVectorizer(min_df=1).fit_transform(corpus)
    k = max(1, min(n, round(math.sqrt(n))))
    km = KMeans(n_clusters=k, n_init='auto', random_state=42)
    return km.fit_predict(vec).tolist()

def _assign_groups_to_zones(vendors: List[Dict], labels: List[int], zones: List[Dict]) -> Dict[int, Optional[int]]:
    if not zones:
        return {g: None for g in set(labels)}
    need = {}
    for v, g in zip(vendors, labels):
        area = v.get("area") or (v.get("width",2)*v.get("height",2))
        need[g] = need.get(g, 0) + max(1, area)
    caps = {z["id"]: z["w"]*z["h"] for z in zones}
    mapping, used = {}, set()
    for g, g_need in sorted(need.items(), key=lambda kv: -kv[1]):
        best_z, best_gap = None, None
        for z in zones:
            if z["id"] in used:
                continue
            gap = abs(caps[z["id"]] - g_need)
            if best_gap is None or gap < best_gap:
                best_z, best_gap = z["id"], gap
        mapping[g] = best_z
        used.add(best_z)
    return mapping

def _pack_rects(grid_w:int, grid_h:int, items: List[Dict], zone: Optional[Dict]) -> Tuple[bool, List[Dict]]:
    x0 = zone["x"] if zone else 0
    y0 = zone["y"] if zone else 0
    W  = zone["w"] if zone else grid_w
    H  = zone["h"] if zone else grid_h

    items = sorted(items, key=lambda it: (not it["vendor"].get("vip", False), -(it["w"]*it["h"])))
    occ = np.zeros((H, W), dtype=bool)
    res = []

    def can_place(x,y,w,h):
        if x+w>W or y+h>H: return False
        return not occ[y:y+h, x:x+w].any()
    def place(x,y,w,h,val=True):
        occ[y:y+h, x:x+w] = val

    def dfs(i:int) -> bool:
        if i == len(items):
            return True
        it = items[i]
        for (ww,hh) in [(it["w"], it["h"]), (it["h"], it["w"])]:
            for y in range(H):
                for x in range(W):
                    if can_place(x,y,ww,hh):
                        place(x,y,ww,hh,True)
                        res.append({"vendor_id": it["id"], "x": x0+x, "y": y0+y, "w": ww, "h": hh})
                        if dfs(i+1):
                            return True
                        res.pop()
                        place(x,y,ww,hh,False)
        return False

    ok = dfs(0)
    return ok, res

def compute_layout(grid_w:int, grid_h:int, vendors:List[Dict], zones:List[Dict], constraints:List[Dict]):
    if not vendors:
        return []

    labels = _cluster_labels(vendors)
    g2z = _assign_groups_to_zones(vendors, labels, zones)
    zmap = {z["id"]: z for z in zones}

    bucket = {}
    for v, g in zip(vendors, labels):
        bucket.setdefault(g2z.get(g), []).append(v)

    placements = []
    for zid, vs in bucket.items():
        zone = zmap.get(zid) if zid else None
        items = []
        for v in vs:
            w = v.get("width",  max(1, int(round((v.get("area",4))**0.5))))
            h = v.get("height", max(1, int(round((v.get("area",4))**0.5))))
            items.append({"id": v["id"], "w": w, "h": h, "vendor": v})

        ok, placed = _pack_rects(grid_w, grid_h, items, zone)
        if not ok and zone:
            ok, placed = _pack_rects(grid_w, grid_h, items, None)
        for p in placed:
            p["zone_id"] = zid
            placements.append(p)

    # TODO: incorporate constraints with local swaps / penalties
    return placements
