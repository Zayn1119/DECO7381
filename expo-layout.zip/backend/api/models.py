from django.db import models

class Event(models.Model):
    name = models.CharField(max_length=200)
    grid_width = models.PositiveIntegerField(default=40)
    grid_height = models.PositiveIntegerField(default=20)
    def __str__(self): return self.name

class Zone(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE)
    name = models.CharField(max_length=50)
    x = models.PositiveIntegerField()
    y = models.PositiveIntegerField()
    w = models.PositiveIntegerField()
    h = models.PositiveIntegerField()
    def __str__(self): return f"{self.event.name}-{self.name}"

class Vendor(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE)
    name = models.CharField(max_length=200)
    area = models.PositiveIntegerField(default=4)
    width = models.PositiveIntegerField(default=2)
    height = models.PositiveIntegerField(default=2)
    tags = models.JSONField(default=list)
    vip = models.BooleanField(default=False)
    power_kw = models.FloatField(default=0.0)
    def __str__(self): return self.name

class VendorConstraint(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE)
    vendor_a = models.ForeignKey(Vendor, on_delete=models.CASCADE, related_name='c_a')
    vendor_b = models.ForeignKey(Vendor, on_delete=models.CASCADE, related_name='c_b')
    type = models.CharField(max_length=20, choices=[('avoid','avoid'),('near','near')])

class Placement(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE)
    vendor = models.ForeignKey(Vendor, on_delete=models.CASCADE)
    zone = models.ForeignKey(Zone, on_delete=models.SET_NULL, null=True, blank=True)
    x = models.PositiveIntegerField()
    y = models.PositiveIntegerField()
    w = models.PositiveIntegerField()
    h = models.PositiveIntegerField()
