from django.contrib import admin
from .models import Event, Zone, Vendor, VendorConstraint, Placement

@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "grid_width", "grid_height")

@admin.register(Zone)
class ZoneAdmin(admin.ModelAdmin):
    list_display = ("id", "event", "name", "x", "y", "w", "h")

@admin.register(Vendor)
class VendorAdmin(admin.ModelAdmin):
    list_display = ("id", "event", "name", "area", "width", "height", "vip", "power_kw", "tags")

@admin.register(VendorConstraint)
class VendorConstraintAdmin(admin.ModelAdmin):
    list_display = ("id", "event", "vendor_a", "vendor_b", "type")

@admin.register(Placement)
class PlacementAdmin(admin.ModelAdmin):
    list_display = ("id", "event", "vendor", "zone", "x", "y", "w", "h")
