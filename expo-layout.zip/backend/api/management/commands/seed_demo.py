from django.core.management.base import BaseCommand
from api.models import Event, Zone, Vendor

class Command(BaseCommand):
    help = "Seed demo event/zones/vendors"

    def handle(self, *args, **kwargs):
        Event.objects.all().delete()

        e = Event.objects.create(name="Tech Expo", grid_width=40, grid_height=20)
        Zone.objects.bulk_create([
            Zone(event=e, name="AI",     x=0,  y=0,  w=20, h=10),
            Zone(event=e, name="Maker",  x=20, y=0,  w=20, h=10),
            Zone(event=e, name="Edu",    x=0,  y=10, w=20, h=10),
            Zone(event=e, name="Health", x=20, y=10, w=20, h=10),
        ])

        vendors = [
            dict(name="RoboLab",     tags=["robot","ai"], area=6,  vip=True),
            dict(name="VisionX",     tags=["ai","cv"],    area=4),
            dict(name="Print3D",     tags=["3d","maker"], area=8),
            dict(name="BioSense",    tags=["health","sensor"], area=6),
            dict(name="EduGo",       tags=["edu","platform"],   area=4),
            dict(name="MetalWorks",  tags=["maker","cnc"], area=9),
            dict(name="CalmAI",      tags=["ai","nlp"], area=4),
            dict(name="PCBPro",      tags=["maker","electronics"], area=6),
        ]
        for v in vendors:
            Vendor.objects.create(event=e, width=2, height=max(1, v["area"]//2), **v)

        self.stdout.write(self.style.SUCCESS("✅ Seeded demo data. Event id=1"))
