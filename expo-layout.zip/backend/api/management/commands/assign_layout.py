from django.core.management.base import BaseCommand
from django.db import transaction
from api.models import Event, Vendor, Zone, VendorConstraint, Placement
from algo_core.layout import compute_layout

class Command(BaseCommand):
    help = "Compute layout for an event and write placements"

    def add_arguments(self, parser):
        parser.add_argument('--event_id', type=int, required=True)

    def handle(self, *args, **opts):
        eid = opts['event_id']
        event = Event.objects.get(id=eid)
        vendors = list(Vendor.objects.filter(event=event).values())
        zones = list(Zone.objects.filter(event=event).values())
        constraints = list(VendorConstraint.objects.filter(event=event).values())

        res = compute_layout(event.grid_width, event.grid_height, vendors, zones, constraints)

        with transaction.atomic():
            Placement.objects.filter(event=event).delete()
            Placement.objects.bulk_create([
                Placement(event=event, vendor_id=p["vendor_id"], zone_id=p.get("zone_id"),
                          x=p["x"], y=p["y"], w=p["w"], h=p["h"])
                for p in res
            ])
        self.stdout.write(self.style.SUCCESS(f"✅ Placed {len(res)} vendors for event {eid}"))
