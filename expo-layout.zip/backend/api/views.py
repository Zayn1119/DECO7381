from django.http import JsonResponse, HttpResponse, HttpResponseBadRequest
from django.db import transaction
from .models import Event, Vendor, Zone, VendorConstraint, Placement
from algo_core.layout import compute_layout

def run_layout(request):
    try:
        event_id = int(request.GET.get("event_id", "1"))
    except ValueError:
        return HttpResponseBadRequest("event_id must be int")

    event = Event.objects.get(id=event_id)
    vendors = list(Vendor.objects.filter(event=event).values())
    zones = list(Zone.objects.filter(event=event).values())
    constraints = list(VendorConstraint.objects.filter(event=event).values())

    res = compute_layout(event.grid_width, event.grid_height, vendors, zones, constraints)

    with transaction.atomic():
        Placement.objects.filter(event=event).delete()
        Placement.objects.bulk_create([
            Placement(event=event, vendor_id=p["vendor_id"], zone_id=p.get("zone_id"),
                      x=p["x"], y=p["y"], w=p["w"], h=p["h"])
            for p in res
        ])

    return JsonResponse({"placed_count": len(res)})

def get_placements(request):
    try:
        event_id = int(request.GET.get("event_id", "1"))
    except ValueError:
        return HttpResponseBadRequest("event_id must be int")

    qs = Placement.objects.filter(event_id=event_id).select_related("vendor", "zone")
    data = [{
        "vendor": p.vendor.name,
        "zone": p.zone.name if p.zone else None,
        "x": p.x, "y": p.y, "w": p.w, "h": p.h
    } for p in qs]
    return JsonResponse({"placements": data})

def viewer(_request):
    html = """
<!doctype html><meta charset="utf-8">
<title>Expo Viewer</title>
<style>
  body{font-family:system-ui, -apple-system, Segoe UI, Roboto, sans-serif;padding:16px}
  canvas{border:1px solid #ccc;display:block;margin-top:12px}
  .legend span{display:inline-block;padding:2px 6px;margin-right:6px;border-radius:4px}
</style>
<h1>Expo Layout Viewer</h1>
<button id="btn">Run Layout & Refresh</button>
<div class="legend" id="legend"></div>
<canvas id="cv" width="800" height="400"></canvas>
<script>
const SCALE=20;
const eventId=1;

async function runAndDraw(){
  await fetch(`/api/run_layout?event_id=${eventId}`);
  const resp = await fetch(`/api/placements?event_id=${eventId}`);
  const data = await resp.json();
  const placements = data.placements || [];
  const cv = document.getElementById('cv');
  const ctx = cv.getContext('2d');
  ctx.clearRect(0,0,cv.width,cv.height);

  const colors={}, palette=['#8ecae6','#ffb703','#fb8500','#90be6d','#f72585','#4cc9f0','#bdb2ff','#ffc6ff'];
  let idx=0;
  for(const p of placements){
    const z = p.zone || 'ALL';
    if(!colors[z]) colors[z] = palette[idx++ % palette.length];
    ctx.fillStyle = colors[z];
    ctx.fillRect(p.x*SCALE, p.y*SCALE, p.w*SCALE, p.h*SCALE);
    ctx.strokeStyle = '#222';
    ctx.strokeRect(p.x*SCALE, p.y*SCALE, p.w*SCALE, p.h*SCALE);
    ctx.fillStyle = '#000';
    ctx.font = '10px sans-serif';
    ctx.fillText(p.vendor, p.x*SCALE+2, p.y*SCALE+12);
  }

  document.getElementById('legend').innerHTML =
    Object.entries(colors).map(([z,c])=>`<span style="background:${c}">${z}</span>`).join('');
}
document.getElementById('btn').onclick = runAndDraw;
</script>
"""
    return HttpResponse(html)
