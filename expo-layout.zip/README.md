# Expo Layout (Minimal Django Package)

## Quick Start
```bash
cd backend
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# Windows
# .venv\Scripts\activate

pip install -r ../requirements.txt

python manage.py makemigrations
python manage.py migrate

python manage.py seed_demo
python manage.py assign_layout --event_id=1

python manage.py runserver
```

Then open:
- http://127.0.0.1:8000/viewer/ (simple canvas visualization)
- http://127.0.0.1:8000/api/placements?event_id=1 (JSON output)
- http://127.0.0.1:8000/admin/ (Django admin; create superuser first if needed)

## Notes
- SQLite is used for development by default.
- The algorithm lives in `backend/algo_core/layout.py`. You can extend it with constraints and swapping heuristics.
